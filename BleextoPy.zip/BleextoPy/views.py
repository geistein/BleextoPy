from django.template.loader  import  get_template
from django.template import loader,Context
from django.template import Context,RequestContext
from django.http import HttpResponse, Http404,HttpResponseRedirect
from django.shortcuts import render_to_response

#from soporte.servicios.models import Clientes

from django.db.models import Q
#from forms import ContactForm
from django.core.mail import send_mail
from django.contrib.auth import authenticate,login,logout
from django.contrib.auth.models import User
from django.contrib.auth.forms import AuthenticationForm
from django.core.context_processors import csrf
from django.contrib.auth.decorators import login_required
from django.utils import simplejson as json
from django_excel_templates import *
import time
import csv
import datetime




def login_view(request):
    form = AuthenticationForm()
    response  = {"form": form}
    response.update(csrf(request))
    if request.method == "POST":
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(username=username, password=password)
        if user is not None:
            if user.is_active:
                login(request, user)
                return render_to_response("demo.html", {'login':login,'user':user})
            else:
                response.update({"error": "usuario inactivo"})
                return render_to_response("login_demo.html", response)
        else:
            response.update({"error": "el usuario o la clave no existe"})
            return render_to_response("login_demo.html", response)

    else:
        return render_to_response("login_demo.html", response)
    return user

def logout_view(request):
    logout(request)
    return HttpResponseRedirect('/login/')
